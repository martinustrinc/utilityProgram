package org.project.exception;

public class FailedUtilityExceptionHandling extends Exception {
    public FailedUtilityExceptionHandling(String message) {
        super(message);
    }
}
